const PokémonBody = document.getElementById("PokémonfoundList");
const txtSearch = document.getElementById("txtSearch");
const loader = document.getElementById("loader");
const goToFavoritesBtn = document.getElementById("goToFavoritesBtn");

document.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);
  const previousQuery = params.get("q") || localStorage.getItem("lastSearch");

  if (previousQuery) {
    txtSearch.value = previousQuery;
    loader.style.display = "block";
    fetchPokémons(previousQuery);
  }

  txtSearch.addEventListener("input", () => {
    const searchQuery = txtSearch.value.trim();
    const newUrl = `${window.location.pathname}?q=${encodeURIComponent(searchQuery)}`;
    window.history.replaceState({}, "", newUrl);
    localStorage.setItem("lastSearch", searchQuery);

    if (searchQuery.length > 0) {
      loader.style.display = "block";
      fetchPokémons(searchQuery);
    } else {
      PokémonBody.innerHTML = "";
    }
  });

  goToFavoritesBtn.addEventListener("click", () => {
    window.location.href = "fav.html";
  });

  PokémonBody.addEventListener("click", (e) => {
    if (e.target.classList.contains("heart-icon")) {
      const card = e.target.closest(".pokemon-card");
      const id = Number(card.dataset.id);
      const name = card.dataset.name;
      const image = card.dataset.image;
      const types = JSON.parse(card.dataset.types);
      const abilities = JSON.parse(card.dataset.abilities);

      toggleFavorite(id, name, image, types, abilities, e.target);
    }
  });
});

function fetchPokémons(searchQuery) {
  fetch(`https://pokeapi.co/api/v2/pokemon/${searchQuery.toLowerCase()}`)
    .then(res => {
      if (!res.ok) throw new Error("Not found");
      return res.json();
    })
    .then(data => {
      displaySinglePokemon(data);
    })
    .catch(() => {
      fetch(`https://pokeapi.co/api/v2/type/${searchQuery.toLowerCase()}`)
        .then(res => {
          if (!res.ok) throw new Error("Type not found");
          return res.json();
        })
        .then(data => {
          displayMultiplePokemons(data.pokemon);
        })
        .catch(() => {
          fetch(`https://pokeapi.co/api/v2/ability/${searchQuery.toLowerCase()}`)
            .then(res => {
              if (!res.ok) throw new Error("Ability not found");
              return res.json();
            })
            .then(data => {
              displayMultiplePokemons(data.pokemon);
            })
            .catch(() => {
              PokémonBody.innerHTML = `<p>No Pokémon found for "${searchQuery}".</p>`;
            });
        });
    })
    .finally(() => {
      loader.style.display = "none";
    });
}

function displaySinglePokemon(pokemon) {
  const isFav = isPokemonFavorited(pokemon.id);
  PokémonBody.innerHTML = `
    <div class="pokemon-card"
         data-id="${pokemon.id}"
         data-name="${pokemon.name}"
         data-image="${pokemon.sprites.front_default}"
         data-types='${JSON.stringify(pokemon.types)}'
         data-abilities='${JSON.stringify(pokemon.abilities)}'>
      <img src="${pokemon.sprites.front_default}" alt="${pokemon.name}">
      <h2>${pokemon.name}</h2>
      <p><strong>ID:</strong> ${pokemon.id}</p>
      <p><strong>Type(s):</strong> ${pokemon.types.map(t => t.type.name).join(", ")}</p>
      <p><strong>Abilities:</strong> ${pokemon.abilities.map(a => a.ability.name).join(", ")}</p>
      <button class="favorite-btn ${isFav ? 'favorited' : ''}">
        <span class="heart-icon">${isFav ? '❤️' : '♡'}</span> Favorite
      </button>
    </div>
  `;
}

function displayMultiplePokemons(pokemonList) {
  const promises = pokemonList.slice(0, 20).map(p =>
    fetch(p.pokemon.url).then(res => res.json())
  );

  Promise.all(promises).then(results => {
    PokémonBody.innerHTML = results.map(pokemon => {
      const isFav = isPokemonFavorited(pokemon.id);
      return `
        <div class="pokemon-card"
             data-id="${pokemon.id}"
             data-name="${pokemon.name}"
             data-image="${pokemon.sprites.front_default}"
             data-types='${JSON.stringify(pokemon.types)}'
             data-abilities='${JSON.stringify(pokemon.abilities)}'>
          <img src="${pokemon.sprites.front_default}" alt="${pokemon.name}">
          <h2>${pokemon.name}</h2>
          <p><strong>ID:</strong> ${pokemon.id}</p>
          <p><strong>Type(s):</strong> ${pokemon.types.map(t => t.type.name).join(", ")}</p>
          <p><strong>Abilities:</strong> ${pokemon.abilities.map(a => a.ability.name).join(", ")}</p>
          <button class="favorite-btn ${isFav ? 'favorited' : ''}">
            <span class="heart-icon">${isFav ? '❤️' : '♡'}</span> Favorite
          </button>
        </div>
      `;
    }).join("");
  });
}

function isPokemonFavorited(id) {
  const favorites = JSON.parse(localStorage.getItem("favorites") || "[]");
  return favorites.some(p => p.id === id);
}

function toggleFavorite(id, name, image, types, abilities, heartElement) {
  let favorites = JSON.parse(localStorage.getItem("favorites") || "[]");
  const existing = favorites.find(p => p.id === id);

  if (existing) {
    favorites = favorites.filter(p => p.id !== id);
    heartElement.textContent = "♡";
    heartElement.closest(".favorite-btn").classList.remove("favorited");
  } else {
    favorites.push({ id, name, image, types, abilities });
    heartElement.textContent = "❤️";
    heartElement.closest(".favorite-btn").classList.add("favorited");
  }

  localStorage.setItem("favorites", JSON.stringify(favorites));
}
