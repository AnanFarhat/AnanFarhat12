document.addEventListener("DOMContentLoaded", () => {
    const goBackToSearchBtn = document.getElementById("goBackToSearchBtn");
    const container = document.getElementById("favoritePokémons");
    const sortSelect = document.getElementById("sortSelect");
    const downloadBtn = document.getElementById("downloadBtn");

downloadBtn.addEventListener("click", () => {
    const favorites = JSON.parse(localStorage.getItem("favorites") || "[]");
    const jsonString = JSON.stringify(favorites, null, 2);
    const blob = new Blob([jsonString], { type: "application/json" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "favorites.json";
    a.click();

    URL.revokeObjectURL(url);
});

    goBackToSearchBtn.addEventListener("click", () => {
        window.location.href = "Main.html";
        
            
    });

    let favorites = JSON.parse(localStorage.getItem("favorites") || "[]");

    function renderFavorites() {
        container.innerHTML = "";

        const sortBy = sortSelect.value;

        favorites.sort((a, b) => {
            if (sortBy === "id") return a.id - b.id;
            else return a.name.localeCompare(b.name);
        });

        if (favorites.length === 0) {
            container.innerHTML = "<p>No favorites yet!</p>";
            return;
        }

        favorites.forEach(pokemon => {
            const card = document.createElement("div");
            card.className = "pokemon-card";
            card.dataset.id = pokemon.id;
            card.innerHTML = `
                <img src="${pokemon.image}" alt="${pokemon.name}">
                <h2>${pokemon.name}</h2>
                <p><strong>ID:</strong> ${pokemon.id}</p>
                <p><strong>Type(s):</strong> ${pokemon.types.map(t => t.type.name).join(", ")}</p>
                <p><strong>Abilities:</strong> ${pokemon.abilities.map(a => a.ability.name).join(", ")}</p>
                <button class="remove-btn">❤️ Remove</button>
            `;
            container.appendChild(card);
        });
    }

    sortSelect.addEventListener("change", renderFavorites);

    container.addEventListener("click", (e) => {
        if (e.target.classList.contains("remove-btn")) {
            const card = e.target.closest(".pokemon-card");
            const id = Number(card.dataset.id);
            favorites = favorites.filter(p => p.id !== id);
            localStorage.setItem("favorites", JSON.stringify(favorites));
            renderFavorites();
        }
    });

    renderFavorites();
});
